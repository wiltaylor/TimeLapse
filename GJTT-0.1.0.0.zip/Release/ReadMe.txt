This is a simple tool I bashed together after Ludum Dare 40 to create better timelapes.

Be warned this tool is very much in alpha and will have sharp edges.

Simply run CaptureTool.exe and tell it where you want to store your snapshots too and it will start doing so. It will also hide itself in the notification area so it won't end up in your screen shots.

After you are done you can then use VideoGenerator.exe to create a video file. This is broken up into 3 stages.

* Resize - This stage resizes the images so they are the right dimensions to put into a video.
* Video - This stage generates the video file.
* Audio - This stage adds audio to the video file.

Once the file is generated you can upload it straight to youtube like normal.

Please log all bugs and feature requests to the git repository http://www.github.com/wiltaylor/TimeLapse